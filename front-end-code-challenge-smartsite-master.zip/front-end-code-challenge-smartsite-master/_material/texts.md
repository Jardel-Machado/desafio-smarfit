# Header

> REABERTURA SMART FIT

> O horário de funcionamento das nossas unidades está seguindo os decretos de cada município. Por isso, confira aqui se a sua unidade está aberta e as medidas de segurança que estamos seguindo.

# Form

> Horário

> Qual período quer treinar?

> Manhã 06:00 às 12:00

> Tarde 12:01 às 18:00

> Noite 18:01 às 23:00

> Exibir unidades fechadas

> Encontrar unidade

> Limpar

# List

# Legend

> Máscara

> Toalha

> Bebedouro

> Vestiários

> Obrigatório

> Recomendado

> Parcial

> Proibido

> Liberado

> Fechado

# Footer

> Todos os direitos reservados - 2020
