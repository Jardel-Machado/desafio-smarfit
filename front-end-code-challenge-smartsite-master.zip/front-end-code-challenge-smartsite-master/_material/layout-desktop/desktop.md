# Layout desktop

![dheader](dheader.png)

![dform](dform.png)

![dlegend](dlegend.png)

![dlist](dlist.png)

![dfooter](dfooter.png)
