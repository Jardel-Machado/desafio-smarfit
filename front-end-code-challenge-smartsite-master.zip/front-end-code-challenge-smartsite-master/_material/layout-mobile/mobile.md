# Layout mobile

![header](header.png)

![form](form.png)

![legend](legend.png)

![list](list.png)

![footer](footer.png)
